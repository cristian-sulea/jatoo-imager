/*
 * Copyright (C) Cristian Sulea ( http://cristian.sulea.net )
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jatoo.imager;

public class JaTooImagerTest {

  public static void main(String[] args) throws Exception {

    // JaTooImagerLauncher.main(null);
//    JaTooImagerLauncher.main(new String[] { "C:\\Temp\\Roberto" });
    JaTooImagerLauncher.main(new String[] { "c:\\Temp2" });
    // JaTooImagerLauncher.main(new String[] { "C:\\Temp\\x\\IMG_8791.JPG",
    // "C:\\Temp\\x\\IMG_8791.JPG" });

    // JaTooImager.main(new String[] { "C:\\Temp\\photos2" });

    //
    // create logo

    // BufferedImage image = ImageUtils.create("JaToo Imager", new
    // Font("Agency FB", Font.BOLD, 60), Color.BLACK, true);
    // BufferedImage image = ImageUtils.create("JaToo Exec", new
    // Font("Agency FB", Font.BOLD, 60), Color.BLACK, true);
    // ImageUtils.writePNG(image, new File("c:\\logo.png"));
  }

}
