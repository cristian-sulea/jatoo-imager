#!/bin/sh

java -cp "lib/*" jatoo.imager.JaTooImagerLauncher
