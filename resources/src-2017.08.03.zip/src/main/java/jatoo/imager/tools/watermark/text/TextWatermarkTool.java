/*
 * Copyright (C) Cristian Sulea ( http://cristian.sulea.net )
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jatoo.imager.tools.watermark.text;

import jatoo.image.ImageUtils;
import jatoo.imager.JaTooImager;
import jatoo.imager.JaTooImagerTool;
import jatoo.properties.FileProperties;
import jatoo.ui.ColorButton;
import jatoo.ui.ComboBox;
import jatoo.ui.FontList;
import jatoo.ui.IntegerSpinner;
import jatoo.ui.SliderWithSpinner;
import jatoo.ui.TextField;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.HierarchyEvent;
import java.awt.event.HierarchyListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.font.FontRenderContext;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import net.miginfocom.swing.MigLayout;

/**
 * Text watermark tool.
 * 
 * @author <a href="http://cristian.sulea.net" rel="author">Cristian Sulea</a>
 * @version 0.2, September 8, 2014
 */
@SuppressWarnings("serial")
public class TextWatermarkTool extends JaTooImagerTool {

  private static final String DEFAULT_TEXT = "Copyright (C) Cristian Sulea ( http://cristian.sulea.net )";

  private static final Font DEFAULT_FONT = new Font(Font.DIALOG, Font.PLAIN, 12);
  private static final boolean DEFAULT_FONT_STYLE_BOLD = false;
  private static final boolean DEFAULT_FONT_STYLE_ITALIC = false;
  private static final int DEFAULT_FONT_SIZE = 12;
  private static final Integer[] DEFAULT_FONT_SIZE_VALUES = new Integer[] { 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 36, 40, 44, 48, 56, 64, 72 };
  private static final Color DEFAULT_COLOR = Color.WHITE;
  private static final boolean DEFAULT_ANTIALIASING = true;
  private static final int DEFAULT_PADDING = 10;
  private static final int DEFAULT_ALPHA = 80;
  private static final boolean DEFAULT_SHADOW = true;
  private static final Color DEFAULT_SHADOW_COLOR = Color.BLACK;
  private static final int DEFAULT_SHADOW_DISTANCE = 1;
  private static final int DEFAULT_SHADOW_SIZE = 1;
  private static final int DEFAULT_SHADOW_ANGLE = 30;
  private static final int DEFAULT_SHADOW_ALPHA = 50;

  private TextField textField;

  private FontList fontList;

  private JLabel fontStyleLabel;
  private JCheckBox fontStyleBoldCheckBox;
  private JCheckBox fontStyleItalicCheckBox;

  private JLabel fontSizeLabel;
  private ComboBox<Integer> fontSizeComboBox;

  private JLabel colorLabel;
  private ColorButton colorButton;

  private JCheckBox antialiasingCheckBox;

  private JRadioButton[] anchorRadioButtons;

  private JLabel paddingLeftLabel;
  private IntegerSpinner paddingLeftSpinner;
  private JLabel paddingTopLabel;
  private IntegerSpinner paddingTopSpinner;
  private JLabel paddingRightLabel;
  private IntegerSpinner paddingRightSpinner;
  private JLabel paddingBottomLabel;
  private IntegerSpinner paddingBottomSpinner;

  private SliderWithSpinner alphaSlider;

  private JCheckBox shadowCheckBox;
  private JLabel shadowColorLabel;
  private ColorButton shadowColorButton;
  private JLabel shadowDistanceLabel;
  private IntegerSpinner shadowDistanceSpinner;
  private JLabel shadowSizeLabel;
  private IntegerSpinner shadowSizeSpinner;
  private JLabel shadowAngleLabel;
  private SliderWithSpinner shadowAngleSlider;
  private JLabel shadowAlphaLabel;
  private SliderWithSpinner shadowAlphaSlider;

  @Override
  public int getPriority() {
    return 100;
  }

  @Override
  protected JComponent initImpl(final JaTooImager imager, final FileProperties properties) {

    //
    // handy listeners

    final ChangeListener imagerUpdatePreviewChangeListener = new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        imager.updatePreview();
      }
    };

    final ItemListener imagerUpdatePreviewItemListener = new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        imager.updatePreview();
      }
    };

    final ItemListener imagerUpdatePreviewItemListenerSelected = new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        if (e.getStateChange() == ItemEvent.SELECTED) {
          imager.updatePreview();
        }
      }
    };

    //
    // components

    textField = new TextField(properties.getPropertyAsString("text", DEFAULT_TEXT));
    textField.setSelectAllOnFocus(true);
    textField.addKeyListener(new KeyAdapter() {
      public void keyReleased(KeyEvent e) {
        imager.updatePreview();
      }
    });

    fontList = new FontList();
    fontList.setVisibleRowCount(5);

    final String storedFont = properties.getProperty("font", DEFAULT_FONT.getName());

    for (int i = 0; i < fontList.getModel().getSize(); i++) {
      Font font = (Font) fontList.getModel().getElementAt(i);
      if (font.getName().equals(storedFont)) {
        fontList.setSelectedIndex(i);
        break;
      }
    }

    fontList.addHierarchyListener(new HierarchyListener() {
      public void hierarchyChanged(HierarchyEvent e) {
        if (e.getChangeFlags() == HierarchyEvent.DISPLAYABILITY_CHANGED) {
          if (fontList.isVisible()) {
            fontList.ensureIndexIsVisible(fontList.getSelectedIndex());
          }
        }
      }
    });

    fontList.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting()) {
          imager.updatePreview();
        }
      }
    });

    fontStyleLabel = new JLabel(getText("fontStyleLabel.text"));

    fontStyleBoldCheckBox = new JCheckBox(getText("fontStyleBoldCheckBox.text"), null, properties.getPropertyAsBoolean("fontStyleBold", DEFAULT_FONT_STYLE_BOLD));
    fontStyleBoldCheckBox.addItemListener(imagerUpdatePreviewItemListener);

    fontStyleItalicCheckBox = new JCheckBox(getText("fontStyleItalicCheckBox.text"), null, properties.getPropertyAsBoolean("fontStyleItalic", DEFAULT_FONT_STYLE_ITALIC));
    fontStyleItalicCheckBox.addItemListener(imagerUpdatePreviewItemListener);

    fontSizeLabel = new JLabel(getText("fontSizeLabel.text"));

    fontSizeComboBox = new ComboBox<>(DEFAULT_FONT_SIZE_VALUES);
    fontSizeComboBox.setEditable(true);
    fontSizeComboBox.getEditorComponent().setColumns(2);
    fontSizeComboBox.getEditorComponent().setNumericInteger(true);
    fontSizeComboBox.getEditorComponent().setNegativeAllowed(false);
    fontSizeComboBox.getEditorComponent().setSelectAllOnFocus(true);
    fontSizeComboBox.getEditorComponent().setText(properties.getPropertyAsInt("fontSize", DEFAULT_FONT_SIZE));
    fontSizeComboBox.setSelectedItem(fontSizeComboBox.getEditorComponent().getTextAsInteger(DEFAULT_FONT_SIZE));
    fontSizeComboBox.addItemListener(imagerUpdatePreviewItemListenerSelected);

    colorLabel = new JLabel(getText("colorLabel.text"));
    colorButton = new ColorButton(properties.getPropertyAsColor("color", DEFAULT_COLOR));
    colorButton.addSelectedColorPropertyChangeListener(new PropertyChangeListener() {
      public void propertyChange(PropertyChangeEvent e) {
        imager.updatePreview();
      }
    });

    antialiasingCheckBox = new JCheckBox(getText("antialiasingCheckBox.text"), null, properties.getPropertyAsBoolean("antialiasing", DEFAULT_ANTIALIASING));
    antialiasingCheckBox.addItemListener(imagerUpdatePreviewItemListener);

    ButtonGroup anchorGroup = new ButtonGroup();
    anchorRadioButtons = new JRadioButton[9];
    for (int i = 0; i < anchorRadioButtons.length; i++) {
      anchorGroup.add(anchorRadioButtons[i] = new JRadioButton());
    }

    anchorRadioButtons[properties.getPropertyAsInt("anchor", 0)].setSelected(true);

    for (int i = 0; i < anchorRadioButtons.length; i++) {

      anchorRadioButtons[i].addItemListener(imagerUpdatePreviewItemListenerSelected);

      anchorRadioButtons[i].addItemListener(new ItemListener() {
        public void itemStateChanged(ItemEvent e) {
          if (e.getStateChange() == ItemEvent.SELECTED) {
            updatePaddingFields();
          }
        }
      });
    }

    paddingLeftLabel = new JLabel(getText("paddingLeftLabel.text"));
    paddingLeftSpinner = new IntegerSpinner(properties.getPropertyAsInt("paddingLeft", DEFAULT_PADDING), 1, Integer.MAX_VALUE, 1, "# 'px'");
    paddingLeftSpinner.addChangeListener(imagerUpdatePreviewChangeListener);
    paddingLeftSpinner.setColumns(4);

    paddingTopLabel = new JLabel(getText("paddingTopLabel.text"));
    paddingTopSpinner = new IntegerSpinner(properties.getPropertyAsInt("paddingTop", DEFAULT_PADDING), 1, Integer.MAX_VALUE, 1, "# 'px'");
    paddingTopSpinner.addChangeListener(imagerUpdatePreviewChangeListener);
    paddingTopSpinner.setColumns(4);

    paddingRightLabel = new JLabel(getText("paddingRightLabel.text"));
    paddingRightSpinner = new IntegerSpinner(properties.getPropertyAsInt("paddingRight", DEFAULT_PADDING), 1, Integer.MAX_VALUE, 1, "# 'px'");
    paddingRightSpinner.addChangeListener(imagerUpdatePreviewChangeListener);
    paddingRightSpinner.setColumns(4);

    paddingBottomLabel = new JLabel(getText("paddingBottomLabel.text"));
    paddingBottomSpinner = new IntegerSpinner(properties.getPropertyAsInt("paddingBottom", DEFAULT_PADDING), 1, Integer.MAX_VALUE, 1, "# 'px'");
    paddingBottomSpinner.addChangeListener(imagerUpdatePreviewChangeListener);
    paddingBottomSpinner.setColumns(4);

    alphaSlider = new SliderWithSpinner(0, 100, properties.getPropertyAsInt("alpha", DEFAULT_ALPHA));
    alphaSlider.setSpinnerPattern("# '%'");
    alphaSlider.addChangeListener(imagerUpdatePreviewChangeListener);

    shadowCheckBox = new JCheckBox(getText("shadowCheckBox.text"), null, properties.getPropertyAsBoolean("shadow", DEFAULT_SHADOW));
    shadowCheckBox.addItemListener(imagerUpdatePreviewItemListener);

    shadowColorLabel = new JLabel(getText("shadowColorLabel.text"));
    shadowColorButton = new ColorButton(properties.getPropertyAsColor("shadowColor", DEFAULT_SHADOW_COLOR));
    shadowColorButton.addSelectedColorPropertyChangeListener(new PropertyChangeListener() {
      public void propertyChange(PropertyChangeEvent e) {
        imager.updatePreview();
      }
    });

    shadowDistanceLabel = new JLabel(getText("shadowDistanceLabel.text"));
    shadowDistanceSpinner = new IntegerSpinner(properties.getPropertyAsInt("shadowDistance", DEFAULT_SHADOW_DISTANCE), 1, Integer.MAX_VALUE, 1, "# 'px'");
    shadowDistanceSpinner.setColumns(4);
    shadowDistanceSpinner.addChangeListener(imagerUpdatePreviewChangeListener);

    shadowSizeLabel = new JLabel(getText("shadowSizeLabel.text"));
    shadowSizeSpinner = new IntegerSpinner(properties.getPropertyAsInt("shadowSize", DEFAULT_SHADOW_SIZE), 1, Integer.MAX_VALUE, 1, "# 'px'");
    shadowSizeSpinner.setColumns(4);
    shadowSizeSpinner.addChangeListener(imagerUpdatePreviewChangeListener);

    shadowAngleLabel = new JLabel(getText("shadowAngleLabel.text"));
    shadowAngleSlider = new SliderWithSpinner(0, 360, properties.getPropertyAsInt("shadowAngle", DEFAULT_SHADOW_ANGLE));
    shadowAngleSlider.setSpinnerPattern("# '°'");
    shadowAngleSlider.addChangeListener(imagerUpdatePreviewChangeListener);

    shadowAlphaLabel = new JLabel(getText("shadowAlphaLabel.text"));
    shadowAlphaSlider = new SliderWithSpinner(0, 100, properties.getPropertyAsInt("shadowAlpha", DEFAULT_SHADOW_ALPHA));
    shadowAlphaSlider.setSpinnerPattern("# '%'");
    shadowAlphaSlider.addChangeListener(imagerUpdatePreviewChangeListener);

    //
    //

    JPanel textPanel = new JPanel(new MigLayout("fillx", "fill"));
    textPanel.setBorder(BorderFactory.createTitledBorder(getText("text.title")));
    textPanel.add(textField);

    JPanel fontPanel = new JPanel(new MigLayout("wrap 2", "[]3*rel[]", "[fill, sg a][fill, sg a][fill, sg a][fill,grow]"));
    fontPanel.setBorder(BorderFactory.createTitledBorder(getText("font.title")));

    fontPanel.add(new JScrollPane(fontList), "spany");

    fontPanel.add(fontStyleLabel, "cell 1 0");
    fontPanel.add(fontStyleBoldCheckBox, "cell 1 0");
    fontPanel.add(fontStyleItalicCheckBox, "cell 1 0");

    fontPanel.add(fontSizeLabel, "cell 1 1");
    fontPanel.add(fontSizeComboBox, "cell 1 1");
    fontPanel.add(new JLabel(" "), "cell 1 1");
    fontPanel.add(colorLabel, "cell 1 1");
    fontPanel.add(colorButton, "cell 1 1");

    fontPanel.add(antialiasingCheckBox, "cell 1 2");

    JPanel anchorPanel = new JPanel(new MigLayout("fill, wrap 3", "", ""));
    anchorPanel.setBorder(BorderFactory.createTitledBorder(getText("anchor.title")));
    for (int i = 0; i < anchorRadioButtons.length; i++) {
      anchorPanel.add(anchorRadioButtons[i]);
    }

    JPanel paddingPanel = new JPanel(new MigLayout("fill, wrap 2", "[fill, grow][fill]"));
    paddingPanel.setBorder(BorderFactory.createTitledBorder(getText("padding.title")));
    paddingPanel.add(paddingLeftLabel);
    paddingPanel.add(paddingLeftSpinner);
    paddingPanel.add(paddingTopLabel);
    paddingPanel.add(paddingTopSpinner);
    paddingPanel.add(paddingRightLabel);
    paddingPanel.add(paddingRightSpinner);
    paddingPanel.add(paddingBottomLabel);
    paddingPanel.add(paddingBottomSpinner);

    JPanel alphaPanel = new JPanel(new MigLayout("fillx", "fill"));
    alphaPanel.setBorder(BorderFactory.createTitledBorder(getText("alpha.title")));
    alphaPanel.add(alphaSlider);

    JPanel shadowPanel = new JPanel(new MigLayout("fillx, wrap 2", "[][fill, grow]", "fill, sg a"));
    shadowPanel.setBorder(BorderFactory.createTitledBorder(getText("shadow.title")));

    shadowPanel.add(shadowCheckBox, "spanx");

    shadowPanel.add(shadowColorLabel, "cell 0 1, spanx");
    shadowPanel.add(shadowColorButton, "cell 0 1");
    shadowPanel.add(new JLabel(" "), "cell 0 1");
    shadowPanel.add(shadowDistanceLabel, "cell 0 1");
    shadowPanel.add(shadowDistanceSpinner, "cell 0 1");
    shadowPanel.add(new JLabel(" "), "cell 0 1");
    shadowPanel.add(shadowSizeLabel, "cell 0 1");
    shadowPanel.add(shadowSizeSpinner, "cell 0 1");

    shadowPanel.add(shadowAngleLabel);
    shadowPanel.add(shadowAngleSlider);
    shadowPanel.add(shadowAlphaLabel);
    shadowPanel.add(shadowAlphaSlider);

    JPanel panel = new JPanel(new MigLayout("insets 0, wrap 3, fillx", "[fill][fill][fill, grow]", "fill"));
    panel.add(textPanel, "spanx");
    panel.add(fontPanel);
    panel.add(anchorPanel);
    panel.add(paddingPanel);
    panel.add(alphaPanel, "spanx");
    panel.add(shadowPanel, "spanx");
    return panel;
  }

  @Override
  protected void setEnabledImpl(boolean enabled) {

    textField.setEnabled(enabled);

    fontList.setEnabled(enabled);

    fontStyleLabel.setEnabled(enabled);
    fontStyleBoldCheckBox.setEnabled(enabled);
    fontStyleItalicCheckBox.setEnabled(enabled);

    fontSizeLabel.setEnabled(enabled);
    fontSizeComboBox.setEnabled(enabled);

    colorLabel.setEnabled(enabled);
    colorButton.setEnabled(enabled);

    antialiasingCheckBox.setEnabled(enabled);

    alphaSlider.setEnabled(enabled);

    for (int i = 0; i < anchorRadioButtons.length; i++) {
      anchorRadioButtons[i].setEnabled(enabled);
    }

    paddingLeftLabel.setEnabled(enabled);
    paddingLeftSpinner.setEnabled(enabled);
    paddingTopLabel.setEnabled(enabled);
    paddingTopSpinner.setEnabled(enabled);
    paddingRightLabel.setEnabled(enabled);
    paddingRightSpinner.setEnabled(enabled);
    paddingBottomLabel.setEnabled(enabled);
    paddingBottomSpinner.setEnabled(enabled);

    shadowCheckBox.setEnabled(enabled);

    shadowColorLabel.setEnabled(enabled);
    shadowColorButton.setEnabled(enabled);
    shadowDistanceLabel.setEnabled(enabled);
    shadowDistanceSpinner.setEnabled(enabled);
    shadowSizeLabel.setEnabled(enabled);
    shadowSizeSpinner.setEnabled(enabled);

    shadowAngleLabel.setEnabled(enabled);
    shadowAngleSlider.setEnabled(enabled);
    shadowAlphaLabel.setEnabled(enabled);
    shadowAlphaSlider.setEnabled(enabled);

    if (enabled) {
      updatePaddingFields();
    }
  }

  @Override
  protected void storePropertiesImpl(FileProperties properties) {

    properties.setProperty("text", textField.getText());

    properties.setProperty("font", fontList.getSelectedFont().getName());

    properties.setProperty("fontStyleBold", fontStyleBoldCheckBox.isSelected());
    properties.setProperty("fontStyleItalic", fontStyleItalicCheckBox.isSelected());

    properties.setProperty("fontSize", (Integer) fontSizeComboBox.getSelectedItem());

    properties.setProperty("color", colorButton.getColor());

    properties.setProperty("antialiasing", antialiasingCheckBox.isSelected());

    for (int i = 0; i < anchorRadioButtons.length; i++) {
      if (anchorRadioButtons[i].isSelected()) {
        properties.setProperty("anchor", i);
      }
    }

    properties.setProperty("paddingLeft", paddingLeftSpinner.getValue());
    properties.setProperty("paddingTop", paddingTopSpinner.getValue());
    properties.setProperty("paddingRight", paddingRightSpinner.getValue());
    properties.setProperty("paddingBottom", paddingBottomSpinner.getValue());

    properties.setProperty("alpha", alphaSlider.getValue());

    properties.setProperty("shadow", shadowCheckBox.isSelected());
    properties.setProperty("shadowColor", shadowColorButton.getColor());
    properties.setProperty("shadowDistance", (Integer) shadowDistanceSpinner.getValue());
    properties.setProperty("shadowSize", (Integer) shadowSizeSpinner.getValue());
    properties.setProperty("shadowAngle", shadowAngleSlider.getValue());
    properties.setProperty("shadowAlpha", shadowAlphaSlider.getValue());
  }

  @Override
  protected void restoreDefaults() {

    // textField.setText(DEFAULT_TEXT);

    final String defaultFont = DEFAULT_FONT.getName();
    for (int i = 0; i < fontList.getModel().getSize(); i++) {
      Font font = (Font) fontList.getModel().getElementAt(i);
      if (font.getName().equals(defaultFont)) {
        fontList.setSelectedIndex(i);
        fontList.ensureIndexIsVisible(i);
        break;
      }
    }

    fontStyleBoldCheckBox.setSelected(DEFAULT_FONT_STYLE_BOLD);
    fontStyleItalicCheckBox.setSelected(DEFAULT_FONT_STYLE_ITALIC);

    fontSizeComboBox.getEditorComponent().setText(DEFAULT_FONT_SIZE);
    fontSizeComboBox.setSelectedItem(fontSizeComboBox.getEditorComponent().getTextAsInteger(DEFAULT_FONT_SIZE));

    colorButton.setColor(DEFAULT_COLOR);

    antialiasingCheckBox.setSelected(DEFAULT_ANTIALIASING);

    anchorRadioButtons[0].setSelected(true);

    paddingLeftSpinner.setValue(DEFAULT_PADDING);
    paddingTopSpinner.setValue(DEFAULT_PADDING);
    paddingRightSpinner.setValue(DEFAULT_PADDING);
    paddingBottomSpinner.setValue(DEFAULT_PADDING);

    alphaSlider.setValue(DEFAULT_ALPHA);

    shadowCheckBox.setSelected(DEFAULT_SHADOW);
    shadowColorButton.setColor(DEFAULT_SHADOW_COLOR);
    shadowDistanceSpinner.setValue(DEFAULT_SHADOW_DISTANCE);
    shadowSizeSpinner.setValue(DEFAULT_SHADOW_SIZE);
    shadowAngleSlider.setValue(DEFAULT_SHADOW_ANGLE);
    shadowAlphaSlider.setValue(DEFAULT_SHADOW_ALPHA);
  }

  @Override
  protected BufferedImage processImpl(BufferedImage image) {

    final BufferedImage processedImage = ImageUtils.create(image.getWidth(), image.getHeight(), ImageUtils.hasAlpha(image));

    final Graphics2D g = processedImage.createGraphics();
    g.drawImage(image, 0, 0, null);

    BufferedImage watermark;

    watermark = ImageUtils.create(getWatermarkText(), getWatermarkFont(), getWatermarkFRC(g), getWatermarkColor());

    if (shadowCheckBox.isSelected()) {

      final Color shadowColor = shadowColorButton.getColor();
      final int shadowDistance = (Integer) shadowDistanceSpinner.getValue();
      final int shadowSize = (Integer) shadowSizeSpinner.getValue();
      final int shadowAngle = shadowAngleSlider.getValue();
      final float shadowAlpha = shadowAlphaSlider.getValue() / 100f;

      watermark = ImageUtils.addShadow(watermark, shadowAngle, shadowDistance, shadowSize, shadowAlpha, shadowColor);
    }

    final float alpha = alphaSlider.getValue();

    if (alpha != 100f) {
      g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha / 100f));
    }

    final Point location = getWatermarkLocation(processedImage, watermark);

    g.drawImage(watermark, location.x, location.y, null);
    g.dispose();

    return processedImage;
  }

  private String getWatermarkText() {

    String text = textField.getText();

    if (text == null) {
      text = " ";
    }

    else {

      text = text.trim();

      if (text.length() == 0) {
        text = " ";
      }
    }

    return text;
  }

  private Font getWatermarkFont() {

    final Font selectedFont = fontList.getSelectedFont();
    final boolean isBold = fontStyleBoldCheckBox.isSelected();
    final boolean isItalic = fontStyleItalicCheckBox.isSelected();
    final int size = (Integer) fontSizeComboBox.getSelectedItem();

    int style = Font.PLAIN;
    if (isBold) {
      style = style | Font.BOLD;
    }
    if (isItalic) {
      style = style | Font.ITALIC;
    }

    //
    //

    final Font font;

    if (selectedFont == null) {
      font = DEFAULT_FONT.deriveFont(style, size);
    } else {
      font = selectedFont.deriveFont(style, size);
    }

    return font;
  }

  private FontRenderContext getWatermarkFRC(final Graphics2D g) {

    final boolean isAntialiasing = antialiasingCheckBox.isSelected();
    final FontRenderContext frc = new FontRenderContext(g.getFontRenderContext().getTransform(), isAntialiasing, g.getFontRenderContext().usesFractionalMetrics());

    return frc;
  }

  private Color getWatermarkColor() {
    return colorButton.getColor();
  }

  private Point getWatermarkLocation(BufferedImage image, BufferedImage watermark) {

    final Point location = new Point();

    int anchor = 0;
    for (int i = 0; i < anchorRadioButtons.length; i++) {
      if (anchorRadioButtons[i].isSelected()) {
        anchor = i;
        break;
      }
    }

    switch (anchor) {

      case 0:
        location.x = paddingLeftSpinner.getValue();
        location.y = paddingTopSpinner.getValue();
        break;

      case 1:
        location.x = (image.getWidth() - watermark.getWidth()) / 2;
        location.y = paddingTopSpinner.getValue();
        break;

      case 2:
        location.x = image.getWidth() - watermark.getWidth() - paddingRightSpinner.getValue();
        location.y = paddingTopSpinner.getValue();
        break;

      case 3:
        location.x = paddingLeftSpinner.getValue();
        location.y = (image.getHeight() - watermark.getHeight()) / 2;
        break;

      case 4:
        location.x = (image.getWidth() - watermark.getWidth()) / 2;
        location.y = (image.getHeight() - watermark.getHeight()) / 2;
        break;

      case 5:
        location.x = image.getWidth() - watermark.getWidth() - paddingRightSpinner.getValue();
        location.y = (image.getHeight() - watermark.getHeight()) / 2;
        break;

      case 6:
        location.x = paddingLeftSpinner.getValue();
        location.y = image.getHeight() - watermark.getHeight() - paddingBottomSpinner.getValue();
        break;

      case 7:
        location.x = (image.getWidth() - watermark.getWidth()) / 2;
        location.y = image.getHeight() - watermark.getHeight() - paddingBottomSpinner.getValue();
        break;

      case 8:
      default:
        location.x = image.getWidth() - watermark.getWidth() - paddingRightSpinner.getValue();
        location.y = image.getHeight() - watermark.getHeight() - paddingBottomSpinner.getValue();
        break;
    }

    return location;
  }

  private void updatePaddingFields() {

    int anchor = 0;
    for (int i = 0; i < anchorRadioButtons.length; i++) {
      if (anchorRadioButtons[i].isSelected()) {
        anchor = i;
        break;
      }
    }

    switch (anchor) {

      case 0:
        paddingLeftLabel.setEnabled(true);
        paddingLeftSpinner.setEnabled(true);
        paddingTopLabel.setEnabled(true);
        paddingTopSpinner.setEnabled(true);
        paddingRightLabel.setEnabled(false);
        paddingRightSpinner.setEnabled(false);
        paddingBottomLabel.setEnabled(false);
        paddingBottomSpinner.setEnabled(false);
        break;

      case 1:
        paddingLeftLabel.setEnabled(false);
        paddingLeftSpinner.setEnabled(false);
        paddingTopLabel.setEnabled(true);
        paddingTopSpinner.setEnabled(true);
        paddingRightLabel.setEnabled(false);
        paddingRightSpinner.setEnabled(false);
        paddingBottomLabel.setEnabled(false);
        paddingBottomSpinner.setEnabled(false);
        break;

      case 2:
        paddingLeftLabel.setEnabled(false);
        paddingLeftSpinner.setEnabled(false);
        paddingTopLabel.setEnabled(true);
        paddingTopSpinner.setEnabled(true);
        paddingRightLabel.setEnabled(true);
        paddingRightSpinner.setEnabled(true);
        paddingBottomLabel.setEnabled(false);
        paddingBottomSpinner.setEnabled(false);
        break;

      case 3:
        paddingLeftLabel.setEnabled(true);
        paddingLeftSpinner.setEnabled(true);
        paddingTopLabel.setEnabled(false);
        paddingTopSpinner.setEnabled(false);
        paddingRightLabel.setEnabled(false);
        paddingRightSpinner.setEnabled(false);
        paddingBottomLabel.setEnabled(false);
        paddingBottomSpinner.setEnabled(false);
        break;

      case 4:
        paddingLeftLabel.setEnabled(false);
        paddingLeftSpinner.setEnabled(false);
        paddingTopLabel.setEnabled(false);
        paddingTopSpinner.setEnabled(false);
        paddingRightLabel.setEnabled(false);
        paddingRightSpinner.setEnabled(false);
        paddingBottomLabel.setEnabled(false);
        paddingBottomSpinner.setEnabled(false);
        break;

      case 5:
        paddingLeftLabel.setEnabled(false);
        paddingLeftSpinner.setEnabled(false);
        paddingTopLabel.setEnabled(false);
        paddingTopSpinner.setEnabled(false);
        paddingRightLabel.setEnabled(true);
        paddingRightSpinner.setEnabled(true);
        paddingBottomLabel.setEnabled(false);
        paddingBottomSpinner.setEnabled(false);
        break;

      case 6:
        paddingLeftLabel.setEnabled(true);
        paddingLeftSpinner.setEnabled(true);
        paddingTopLabel.setEnabled(false);
        paddingTopSpinner.setEnabled(false);
        paddingRightLabel.setEnabled(false);
        paddingRightSpinner.setEnabled(false);
        paddingBottomLabel.setEnabled(true);
        paddingBottomSpinner.setEnabled(true);
        break;

      case 7:
        paddingLeftLabel.setEnabled(false);
        paddingLeftSpinner.setEnabled(false);
        paddingTopLabel.setEnabled(false);
        paddingTopSpinner.setEnabled(false);
        paddingRightLabel.setEnabled(false);
        paddingRightSpinner.setEnabled(false);
        paddingBottomLabel.setEnabled(true);
        paddingBottomSpinner.setEnabled(true);
        break;

      case 8:
        paddingLeftLabel.setEnabled(false);
        paddingLeftSpinner.setEnabled(false);
        paddingTopLabel.setEnabled(false);
        paddingTopSpinner.setEnabled(false);
        paddingRightLabel.setEnabled(true);
        paddingRightSpinner.setEnabled(true);
        paddingBottomLabel.setEnabled(true);
        paddingBottomSpinner.setEnabled(true);
        break;
    }

  }

}
