/*
 * Copyright (C) Cristian Sulea ( http://cristian.sulea.net )
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jatoo.imager.tools.resize;

import jatoo.image.ImageUtils;
import jatoo.imager.JaTooImager;
import jatoo.imager.JaTooImagerTool;
import jatoo.properties.FileProperties;
import jatoo.ui.TextField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.image.BufferedImage;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import net.miginfocom.swing.MigLayout;

/**
 * Resize tool for the {@link JaTooImager} application.
 * 
 * @author <a href="http://cristian.sulea.net" rel="author">Cristian Sulea</a>
 * @version 1.1, August 28, 2014
 */
@SuppressWarnings("serial")
public class JaTooImagerToolResize extends JaTooImagerTool {

  public static final int PRIORITY = 1000;

  private static final int DEFAULT_WIDTH = 800;
  private static final int DEFAULT_HEIGHT = 600;

  private JLabel widthLabel;
  private TextField widthTextField;
  private JLabel widthLabelPx;

  private JLabel heightLabel;
  private TextField heightTextField;
  private JLabel heightLabelPx;

  private JRadioButton fitRadioButton;
  private JLabel fitRadioButtonLabel;
  private JRadioButton fillRadioButton;
  private JLabel fillRadioButtonLabel;

  @Override
  public int getPriority() {
    return PRIORITY;
  }

  @Override
  protected final JComponent initImpl(final JaTooImager imager, final FileProperties properties) {

    //
    // initialize width and height fields

    widthTextField = new TextField();
    widthTextField.setNumericInteger(true);
    widthTextField.setNegativeAllowed(false);
    widthTextField.setSelectAllOnFocus(true);
    widthTextField.setColumns(4);

    heightTextField = new TextField();
    heightTextField.setNumericInteger(true);
    heightTextField.setNegativeAllowed(false);
    heightTextField.setSelectAllOnFocus(true);
    heightTextField.setColumns(4);

    //
    // update preview on fields action or focus lost

    final ActionListener previewImageActionListener = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        imager.updatePreview();
      }
    };
    final FocusListener previewImageFocusListener = new FocusAdapter() {
      public void focusLost(FocusEvent e) {
        imager.updatePreview();
      }
    };

    widthTextField.addActionListener(previewImageActionListener);
    heightTextField.addActionListener(previewImageActionListener);

    widthTextField.addFocusListener(previewImageFocusListener);
    heightTextField.addFocusListener(previewImageFocusListener);

    //
    // initialize fit and fill radio buttons

    fitRadioButton = new JRadioButton();
    fitRadioButton.setText(getText("fitRadioButton.text"));
    fitRadioButton.setSelected(true);

    fitRadioButtonLabel = new JLabel(getText("fitRadioButton.label"), JLabel.RIGHT);

    fillRadioButton = new JRadioButton();
    fillRadioButton.setText(getText("fillRadioButton.text"));

    fillRadioButtonLabel = new JLabel(getText("fillRadioButton.label"), JLabel.RIGHT);

    ButtonGroup bgRadioButtons = new ButtonGroup();
    bgRadioButtons.add(fitRadioButton);
    bgRadioButtons.add(fillRadioButton);

    //
    // update preview on radio buttons select

    fitRadioButton.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        if (e.getStateChange() == ItemEvent.SELECTED) {
          imager.updatePreview();
        }
      }
    });

    //
    // restore properties

    widthLabel = new JLabel(getText("widthTextField.label"));
    widthTextField.setText(properties.getPropertyAsInt("width", DEFAULT_WIDTH));
    widthLabelPx = new JLabel(getText("px.label"));

    heightLabel = new JLabel(getText("heightTextField.label"));
    heightTextField.setText(properties.getPropertyAsInt("height", DEFAULT_HEIGHT));
    heightLabelPx = new JLabel(getText("px.label"));

    if ("FIT".equals(properties.getPropertyAsString("type", "FIT"))) {
      fitRadioButton.setSelected(true);
    } else {
      fillRadioButton.setSelected(true);
    }

    //
    // layout

    JPanel dimensionsPanel = new JPanel(new MigLayout("wrap 3", "fill", ""));
    dimensionsPanel.setBorder(BorderFactory.createTitledBorder(getText("dimensions.title")));

    dimensionsPanel.add(widthLabel);
    dimensionsPanel.add(widthTextField);
    dimensionsPanel.add(widthLabelPx);

    dimensionsPanel.add(heightLabel);
    dimensionsPanel.add(heightTextField);
    dimensionsPanel.add(heightLabelPx);

    JPanel typePanel = new JPanel(new MigLayout("wrap 1", "fill", ""));
    typePanel.setBorder(BorderFactory.createTitledBorder(getText("type.title")));

    typePanel.add(fitRadioButton);
    typePanel.add(fitRadioButtonLabel);
    typePanel.add(fillRadioButton);
    typePanel.add(fillRadioButtonLabel);

    JPanel panel = new JPanel(new MigLayout("insets 0, fillx", "[fill][fill, grow]"));

    panel.add(dimensionsPanel);
    panel.add(typePanel);

    return panel;
  }

  @Override
  protected void setEnabledImpl(boolean enabled) {

    widthLabel.setEnabled(enabled);
    widthTextField.setEnabled(enabled);
    widthLabelPx.setEnabled(enabled);

    heightLabel.setEnabled(enabled);
    heightTextField.setEnabled(enabled);
    heightLabelPx.setEnabled(enabled);

    fitRadioButton.setEnabled(enabled);
    fillRadioButton.setEnabled(enabled);

    fitRadioButtonLabel.setEnabled(enabled);
    fillRadioButtonLabel.setEnabled(enabled);
  }

  @Override
  protected void storePropertiesImpl(FileProperties properties) {

    properties.setProperty("width", widthTextField.getTextAsInteger(DEFAULT_WIDTH));
    properties.setProperty("height", heightTextField.getTextAsInteger(DEFAULT_HEIGHT));

    properties.setProperty("type", fitRadioButton.isSelected() ? "FIT" : "FILL");
  }

  @Override
  protected void restoreDefaults() {

    widthTextField.setText(DEFAULT_WIDTH);
    heightTextField.setText(DEFAULT_HEIGHT);

    fitRadioButton.setSelected(true);
  }

  @Override
  protected BufferedImage processImpl(BufferedImage image) {

    if (fitRadioButton.isSelected()) {
      return ImageUtils.resizeToFit(image, widthTextField.getTextAsInteger(DEFAULT_WIDTH), heightTextField.getTextAsInteger(DEFAULT_HEIGHT));
    }

    else {
      return ImageUtils.resizeToFill(image, widthTextField.getTextAsInteger(DEFAULT_WIDTH), heightTextField.getTextAsInteger(DEFAULT_HEIGHT));
    }
  }

}
