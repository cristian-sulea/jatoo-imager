/*
 * Copyright (C) Cristian Sulea ( http://cristian.sulea.net )
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jatoo.imager;

import jatoo.app.App;

import java.awt.Insets;
import java.io.File;

import javax.swing.JComponent;
import javax.swing.UIManager;

/**
 * Intermediate layer to separate the configuration of the JaToo Imager
 * application.
 * 
 * @author <a href="http://cristian.sulea.net" rel="author">Cristian Sulea</a>
 * @version 1.1, August 20, 2014
 */
public abstract class JaTooImagerConfig extends App {

  static final File WORKING_DIRECTORY = new File(new File(new File(System.getProperty("user.home")), ".jatoo"), ".imager");
  static final String LOOK_AND_FEEL = UIManager.getSystemLookAndFeelClassName();

  public JaTooImagerConfig(String title) {
    super(title);
  }

  @Override
  protected final File getWorkingDirectory() {
    return WORKING_DIRECTORY;
  }

  @Override
  protected final boolean isDialog() {
    return false;
  }

  @Override
  protected final boolean isUndecorated() {
    return false;
  }

  @Override
  protected final boolean isResizable() {
    return true;
  }

  @Override
  protected boolean isSizePersistent() {
    return false;
  }

  @Override
  protected final boolean hasTrayIcon() {
    return false;
  }

  @Override
  protected final boolean isGlueToMarginsOnCtrlArrows() {
    return false;
  }

  @Override
  protected final Insets getMarginsGlueGaps() {
    return null;
  }

  @Override
  protected final JComponent getDragToMoveComponent() {
    return null;
  }

  @Override
  protected final void afterInit() {}

}
