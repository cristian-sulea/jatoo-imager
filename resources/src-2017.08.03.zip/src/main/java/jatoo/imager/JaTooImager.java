/*
 * Copyright (C) Cristian Sulea ( http://cristian.sulea.net )
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jatoo.imager;

import jatoo.image.ImageMemoryCache;
import jatoo.image.ImageUtils;
import jatoo.ui.Button;
import jatoo.ui.ImageFileList;
import jatoo.ui.ToggleButton;
import jatoo.ui.WorkerWithProgressDialog;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.AbstractAction;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import net.miginfocom.swing.MigLayout;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * The main class of the JaToo Imager application.
 * 
 * @author <a href="http://cristian.sulea.net" rel="author">Cristian Sulea</a>
 * @version 1.3, September 16, 2014
 */
@SuppressWarnings("serial")
public final class JaTooImager extends JaTooImagerConfig {

  private final Log logger = LogFactory.getLog(getClass());

  private final ImageMemoryCache imageCacheMemory = new ImageMemoryCache();

  private Button processStartButton;

  private ImageFileList images;

  private List<JaTooImagerTool> tools;
  private List<JaTooImagerTool> toolsInContentPane;

  private JaTooImagerOutput output;
  private ToggleButton outputButton;

  private JaTooImagerPreview preview;
  private JaTooImagerPreviewWorker previewWorker;
  private JDialog previewDialog;

  private final Map<File, Integer> rotations = new HashMap<>();

  public JaTooImager(String title) {
    super(title);
  }

  @Override
  protected final void init() {

    //
    // start button

    processStartButton = new Button(getText("imager.processStartButton.text"), new ImageIcon(getClass().getResource("start-32.png")));
    processStartButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {

        if (images.getImages().size() == 0) {
          showWarningMessage(getText("imager.images.empty"));
          return;
        }

        final File outputFolder = output.getFolder();

        if (outputFolder == null) {

          showWarningMessage(getText("imager.outputFolder.warning.folder.null"));

          outputButton.doClick();
          output.doSelectFolder();
        }

        else {

          if (!outputFolder.exists()) {
            if (showQuestion(getText("imager.outputFolder.question.folder.create"))) {
              outputFolder.mkdirs();
            }
          }

          if (!outputFolder.isDirectory()) {

            if (outputFolder.exists()) {
              showWarningMessage(getText("imager.outputFolder.warning.folder.not"));
            } else {
              showWarningMessage(getText("imager.outputFolder.warning.folder.null"));
            }

            outputButton.doClick();
            output.doSelectFolder();
          }

          else {

            boolean process = true;

            if (output.getFolderNotEmptyWarning()) {

              if (outputFolder.list().length > 0) {

                final boolean processIfNotEmpty = showQuestion(getText("imager.outputFolder.question.folder.empty"));

                if (!processIfNotEmpty) {
                  process = false;
                }
              }
            }

            if (process) {

              if (output.isClearFolder()) {
                for (File file : outputFolder.listFiles()) {
                  file.delete();
                }
              }

              new JaTooImagerProcessWorker(outputFolder).start();
            }
          }
        }
      }
    });

    //
    // images list

    images = new ImageFileList(2, 4);

    //
    // on select update preview (if dialog is visible)

    images.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting()) {
          updatePreview(false);
        }
      }
    });

    //
    // on action (double click) update preview (show dialog if not visible)

    images.addMouseListener(new MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
        if (SwingUtilities.isLeftMouseButton(e) && e.getClickCount() >= 2) {
          updatePreview(true);
        }
      }
    });

    //
    // tools

    tools = new ArrayList<>();

    BufferedReader toolsReader = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("tools.classes")));
    String line;

    try {
      while ((line = toolsReader.readLine()) != null) {

        line = line.trim();

        if (line.length() > 0 && !line.startsWith("#")) {
          tools.add(((JaTooImagerTool) Class.forName(line).newInstance()).init(this));
        }
      }
    }

    catch (InstantiationException | IllegalAccessException | ClassNotFoundException | IOException e) {
      throw new IllegalArgumentException("failed to read/init tools classes", e);
    }

    toolsInContentPane = new ArrayList<>(tools);

    Collections.sort(tools, new Comparator<JaTooImagerTool>() {
      public int compare(JaTooImagerTool t1, JaTooImagerTool t2) {
        return t2.getPriority() - t1.getPriority();
      }
    });

    //
    // output

    output = new JaTooImagerOutput(this);
    outputButton = new ToggleButton(getText("imager.outputButton.text"));

    //
    // preview

    preview = new JaTooImagerPreview(this);
    preview.setPreferredSize(new Dimension(800, 600));

    previewDialog = new JDialog(getWindow());
    previewDialog.getContentPane().add(preview);
    previewDialog.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
    previewDialog.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        preview.setImage(null);
        preview.paintImmediately(preview.getBounds());
      }
    });

    //
    // application left/right keys

    setActionForLeftKeyStroke(new AbstractAction() {
      public void actionPerformed(final ActionEvent e) {
        prevImagePreview();
      }
    });

    setActionForRightKeyStroke(new AbstractAction() {
      public void actionPerformed(final ActionEvent e) {
        nextImagePreview();
      }
    });
  }

  @Override
  protected final JComponent getContentPane() {

    //
    // content

    final JPanel contentPane;

    //
    // top pane

    final JPanel topPane = new JPanel(new MigLayout("fill, wrap 1", "[fill, grow]", "[fill][fill, grow]"));
    topPane.add(processStartButton);
    topPane.add(images);

    //
    // create tools & layout content pane

    final JPanel toolsToolbar = new JPanel(new MigLayout("", "fill", "fill"));
    final JPanel toolsContainer = new JPanel(new GridLayout());

    final ButtonGroup toolsButtonGroup = new ButtonGroup();

    //
    // add tools

    for (final JaTooImagerTool tool : toolsInContentPane) {

      final ToggleButton toolButton = new ToggleButton(tool.getTitle());
      toolButton.addItemListener(new ItemListener() {
        public void itemStateChanged(ItemEvent e) {
          if (e.getStateChange() == ItemEvent.SELECTED) {

            toolsContainer.removeAll();
            toolsContainer.add(tool);

            toolsContainer.revalidate();
            toolsContainer.repaint();

            SwingUtilities.invokeLater(new Runnable() {
              public void run() {
                getWindow().pack();
              }
            });
          }
        }
      });

      toolsToolbar.add(toolButton);

      toolsButtonGroup.add(toolButton);
    }

    //
    // add output (as a tool)

    outputButton.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        if (e.getStateChange() == ItemEvent.SELECTED) {

          toolsContainer.removeAll();
          toolsContainer.add(output);

          toolsContainer.revalidate();
          toolsContainer.repaint();

          SwingUtilities.invokeLater(new Runnable() {
            public void run() {
              getWindow().pack();
            }
          });
        }
      }
    });

    JSeparator outputButtonSeparator = new JSeparator(JSeparator.VERTICAL);
    outputButtonSeparator.setMinimumSize(outputButtonSeparator.getPreferredSize());

    toolsToolbar.add(outputButtonSeparator);
    toolsToolbar.add(outputButton);

    toolsButtonGroup.add(outputButton);

    //
    // select first tool

    ((ToggleButton) toolsToolbar.getComponent(0)).setSelected(true);

    //
    // layout

    JSeparator toolsToolbarSeparator1 = new JSeparator(JSeparator.HORIZONTAL);
    toolsToolbarSeparator1.setMinimumSize(toolsToolbarSeparator1.getPreferredSize());

    JSeparator toolsToolbarSeparator2 = new JSeparator(JSeparator.HORIZONTAL);
    toolsToolbarSeparator2.setMinimumSize(toolsToolbarSeparator1.getPreferredSize());

    contentPane = new JPanel(new MigLayout("fill, wrap 1, insets 0, gap 0", "[fill, grow]", "[fill][fill][fill][fill][fill, grow]"));

    contentPane.add(topPane);
    contentPane.add(toolsToolbarSeparator1);
    contentPane.add(toolsToolbar);
    contentPane.add(toolsToolbarSeparator2);
    contentPane.add(toolsContainer);

    //
    // that's all folks

    return contentPane;
  }

  public void addFile(final File file) {
    images.addImage(file);
  }

  public void addFolder(final File folder) {

    final File[] files = folder.listFiles();

    if (files != null && files.length > 0) {
      images.addImages(Arrays.asList(files));
    }
  }

  public void updatePreview() {
    updatePreview(false);
  }

  public void updatePreview(boolean showPreviewDialog) {

    boolean showPreview = false;

    if (showPreviewDialog) {
      showPreview = true;
    }

    else if (previewDialog.isVisible()) {
      showPreview = true;
    }

    //
    // sometimes we simply don't want to show preview
    // even if this method is called

    if (showPreview) {

      File file = images.getSelectedImage();

      if (file == null) {
        previewDialog.setTitle(getText("imager.previewDialog.title"));
        preview.setImage(null);
      }

      else {

        //
        // update the title on preview window

        previewDialog.setTitle(getText("imager.previewDialog.title") + ": " + file.getName());

        //
        // update size & location
        // and show preview window

        if (!previewDialog.isVisible()) {

          previewDialog.setLocation(getWindow().getX() + getWindow().getWidth() + 10, getWindow().getY());
          previewDialog.pack();

          previewDialog.setVisible(true);
        }

        //
        // start the image loader
        // but only after the previous one is stopped

        if (previewWorker != null) {
          previewWorker.stop();
        }

        previewWorker = new JaTooImagerPreviewWorker(file);
        previewWorker.start();
      }
    }
  }

  public final void prevImagePreview() {
    images.selectPrevImage();
  }

  public final void nextImagePreview() {
    images.selectNextImage();
  }

  public final void rotateImageLeft() {
    updateRotation(images.getSelectedImage(), -1);
  }

  public final void rotateImageRight() {
    updateRotation(images.getSelectedImage(), +1);
  }

  private synchronized void updateRotation(final File file, final int count) {

    Integer rotation = rotations.get(file);
    if (rotation == null) {
      rotation = 0;
    }

    rotation += count;

    rotations.put(file, rotation);

    updatePreview();
  }

  private synchronized BufferedImage applyRotation(final File file, final BufferedImage image) {

    Integer rotation = rotations.get(file);

    if (rotation != null && rotation != 0) {

      //
      // use BLACK as background
      // because when saving as JPEG will fail
      // i suppose that transparent/rotated images can not be saved as JPEG

      return ImageUtils.rotate(image, 90 * rotation, Color.BLACK);
    }

    return image;
  }

  private class JaTooImagerProcessWorker extends WorkerWithProgressDialog {

    private final List<String> warnMessages = new ArrayList<>();
    private final List<String> errorMessages = new ArrayList<>();

    private final File outputFolder;

    public JaTooImagerProcessWorker(final File outputFolder) {
      super(processStartButton, getText("imager.processWorker.title"));
      this.outputFolder = outputFolder;
    }

    @Override
    protected void work() {

      final List<File> files = images.getImages();

      for (int i = 0, n = files.size(); i < n; i++) {

        if (isCancelled()) {
          break;
        }

        File file = files.get(i);

        setProgress(100 * i / n, file.getName());

        try {

          //
          // read

          BufferedImage image = ImageUtils.read(file);

          //
          // process (tools) & rotation

          for (JaTooImagerTool tool : tools) {
            image = tool.process(image);
          }

          image = applyRotation(file, image);

          //
          // write

          if (output.isFormatJPEG()) {
            ImageUtils.writeJPEG(image, new File(outputFolder, file.getName()), true);
          }

          else {
            ImageUtils.writePNG(image, new File(outputFolder, file.getName()), true);
          }
        }

        catch (IOException e) {
          warnMessages.add(file.getAbsolutePath() + " ( " + e.getMessage() + " )");
          logger.warn("failed to process image: " + file.getAbsolutePath(), e);
        }

        catch (Exception e) {

          cancel();

          errorMessages.add("unknown exception ( " + e + " )");
          logger.error("unknown exception", e);
        }
      }
    }

    @Override
    protected void done() {

      if (isCancelled()) {
        showInformationMessage(getText("imager.processWorker.cancel"));
      }

      else {

        if (errorMessages.size() > 0) {
          errorMessages.add(0, getText("imager.processWorker.error"));
          showErrorMessages(errorMessages);
        }

        else if (warnMessages.size() > 0) {
          warnMessages.add(0, getText("imager.processWorker.warn"));
          showWarningMessages(warnMessages);
        }

        else {

          for (JaTooImagerTool tool : tools) {
            tool.storeProperties();
          }

          output.storeProperties();

          showTrayInformationMessage(getText("imager.processWorker.success"));
          // showInformationMessage(getText("imager.processWorker.success"));
        }
      }
    }
  }

  private class JaTooImagerPreviewWorker implements Runnable {

    private final File file;

    private FileInputStream stream;
    private boolean stopped = false;

    public JaTooImagerPreviewWorker(final File file) {
      this.file = file;
    }

    public void start() {
      new Thread(this).start();
    }

    @Override
    public void run() {

      BufferedImage image;

      //
      // first of all check the image in the cache

      image = imageCacheMemory.get(file);

      if (image != null) {

        if (logger.isDebugEnabled()) {
          logger.debug("image loaded from memory cache: " + file);
        }
      }

      //
      // the image is not in the cache

      else {

        //
        // show the loader

        preview.showLoader();

        try {

          //
          // load image from the provided file

          stream = new FileInputStream(file);

          image = ImageUtils.read(stream);

          if (logger.isDebugEnabled()) {
            logger.debug("image loaded from file: " + file);
          }

          //
          // update the cache

          imageCacheMemory.put(file, image);
        }

        catch (IOException e) {
          if (!stopped) {
            logger.warn("image could not be read from file: " + file, e);
          }
        }

        finally {
          try {
            stream.close();
          } catch (IOException e) {
            logger.warn("stream could not be closed: " + file, e);
          }
        }
      }

      if (!stopped) {

        for (JaTooImagerTool tool : tools) {
          image = tool.process(image);
        }

        image = applyRotation(file, image);

        preview.setImage(image);
      }

      //
      // hide the loader

      preview.hideLoader();
    }

    public void stop() {

      stopped = true;

      if (stream != null) {
        try {
          stream.close();
        } catch (IOException e) {
          logger.warn("image stream could not be closed: " + file, e);
        }
      }
    }
  }

}
