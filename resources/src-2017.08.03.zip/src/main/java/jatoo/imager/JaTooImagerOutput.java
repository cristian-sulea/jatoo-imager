/*
 * Copyright (C) Cristian Sulea ( http://cristian.sulea.net )
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jatoo.imager;

import jatoo.properties.FileProperties;
import jatoo.ui.FileSelector;
import jatoo.ui.SliderWithSpinner;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.SwingUtilities;

import net.miginfocom.swing.MigLayout;

/**
 * Base class for the {@link JaTooImager} application tools.
 * 
 * @author <a href="http://cristian.sulea.net" rel="author">Cristian Sulea</a>
 * @version 1.1, August 19, 2014
 */
@SuppressWarnings("serial")
public class JaTooImagerOutput extends JComponent {

  private final FileProperties properties;

  private final JCheckBox folderNotEmptyWarningCheckBox;
  private final JCheckBox clearFolderCheckBox;

  private final FileSelector folderSelector;

  private final JRadioButton formatPNGRadioButton;
  private final JRadioButton formatJPEGRadioButton;

  private final JLabel formatQualityLabel;
  private final SliderWithSpinner formatQualitySlider;

  /**
   * Constructs the output for the {@link JaTooImager} application.
   */
  public JaTooImagerOutput(final JaTooImager imager) {

    properties = new FileProperties(new File(imager.getWorkingDirectory(), "output.properties"));
    properties.loadSilently();

    folderNotEmptyWarningCheckBox = new JCheckBox(imager.getText("output.folderNotEmptyWarningCheckBox.text"), properties.getPropertyAsBoolean("folderNotEmptyWarning", false));

    clearFolderCheckBox = new JCheckBox(imager.getText("output.clearFolderCheckBox.text"), properties.getPropertyAsBoolean("clearFolder", false));
    clearFolderCheckBox.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {

        if (e.getStateChange() == ItemEvent.DESELECTED) {
          folderNotEmptyWarningCheckBox.setSelected(true);
        }

        else {

          SwingUtilities.invokeLater(new Runnable() {
            public void run() {

              if (!imager.showQuestion(imager.getText("output.clearFolderCheckBox.question"))) {
                clearFolderCheckBox.setSelected(false);
              }
            }
          });
        }
      }
    });

    folderSelector = new FileSelector();
    folderSelector.setSelectionModeFoldersOnly();
    folderSelector.setFile(properties.getPropertyAsString("folder", null));

    formatPNGRadioButton = new JRadioButton(imager.getText("output.format.checkbox.png.text"));
    formatPNGRadioButton.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        if (e.getStateChange() == ItemEvent.SELECTED) {
          formatQualityLabel.setEnabled(false);
          formatQualitySlider.setEnabled(false);
        }
      }
    });

    formatJPEGRadioButton = new JRadioButton(imager.getText("output.format.checkbox.jpeg.text"));
    formatJPEGRadioButton.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        if (e.getStateChange() == ItemEvent.SELECTED) {
          formatQualityLabel.setEnabled(true);
          formatQualitySlider.setEnabled(true);
        }
      }
    });

    ButtonGroup formatButtonGroup = new ButtonGroup();
    formatButtonGroup.add(formatPNGRadioButton);
    formatButtonGroup.add(formatJPEGRadioButton);

    formatQualityLabel = new JLabel(imager.getText("output.format.quality.label"));
    formatQualitySlider = new SliderWithSpinner(1, 100, properties.getPropertyAsInt("formatQuality", 92));
    formatQualitySlider.setSpinnerPattern("# '%'");

    //
    // restore format selection after all format components are initialized

    final String format = properties.getPropertyAsString("format", "PNG");
    if ("JPEG".equals(format)) {
      formatJPEGRadioButton.setSelected(true);
    } else {
      formatPNGRadioButton.setSelected(true);
    }

    //
    // layout

    JPanel checkboxesPanel = new JPanel(new MigLayout("insets 0"));
    checkboxesPanel.add(folderNotEmptyWarningCheckBox);
    checkboxesPanel.add(clearFolderCheckBox);

    JPanel folderPanel = new JPanel(new MigLayout("fillx, wrap 1", "[fill, grow]", ""));
    folderPanel.setBorder(BorderFactory.createTitledBorder(imager.getText("output.folder.panel.title")));
    folderPanel.add(folderSelector);

    JPanel formatPanel = new JPanel(new MigLayout("fillx, wrap 4", "[][][][fill, grow]", "[align center][]"));
    formatPanel.setBorder(BorderFactory.createTitledBorder(imager.getText("output.format.panel.title")));
    formatPanel.add(formatPNGRadioButton);
    formatPanel.add(new JLabel("   "), "spany");
    formatPanel.add(formatQualityLabel, "spany");
    formatPanel.add(formatQualitySlider, "spany");
    formatPanel.add(formatJPEGRadioButton);

    setLayout(new MigLayout("insets 0, fillx, wrap 1", "[fill, grow]", "fill"));
    add(checkboxesPanel);
    add(folderPanel);
    add(formatPanel);
  }

  public final void storeProperties() {

    properties.setProperty("folderNotEmptyWarning", getFolderNotEmptyWarning());
    properties.setProperty("clearFolder", isClearFolder());
    properties.setProperty("folder", getFolder().getAbsolutePath());

    if (isFormatJPEG()) {
      properties.setProperty("format", "JPEG");
    } else {
      properties.setProperty("format", "PNG");
    }

    properties.setProperty("formatQuality", getFormatQuality());

    properties.saveSilently();
  }

  public final void doSelectFolder() {
    folderSelector.doSelectFile();
  }

  public final boolean getFolderNotEmptyWarning() {
    return folderNotEmptyWarningCheckBox.isSelected();
  }

  public final boolean isClearFolder() {
    return clearFolderCheckBox.isSelected();
  }

  public final File getFolder() {
    return folderSelector.getFile();
  }

  public final boolean isFormatPNG() {
    return formatPNGRadioButton.isSelected();
  }

  public final boolean isFormatJPEG() {
    return formatJPEGRadioButton.isSelected();
  }

  public final int getFormatQuality() {
    return formatQualitySlider.getValue();
  }

}
