/*
 * Copyright (C) Cristian Sulea ( http://cristian.sulea.net )
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jatoo.imager;

import jatoo.ui.Button;
import jatoo.ui.ImageViewer;
import jatoo.ui.Panel;
import jatoo.ui.ToggleButton;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.LayoutManager;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import net.miginfocom.swing.MigLayout;

/**
 * The view (content pane) of the JaToo Imager application.
 * 
 * @author <a href="http://cristian.sulea.net" rel="author">Cristian Sulea</a>
 * @version 0.6, August 19, 2014
 */
@SuppressWarnings("serial")
public class JaTooImagerPreview extends JPanel {

  private final ImageViewer viewer;

  private final Button prevButton;
  private final Button nextButton;

  private final ToggleButton zoomRealSizeBestFitButton;

  private final Button rotateLeftButton;
  private final Button rotateRightButton;

  private final Panel toolbar;

  private final JLabel loader;

  /**
   * Constructs a new view (content pane) for the {@link JaTooImager}
   * application.
   * 
   * @param imager
   *          link to the {@link JaTooImager} application
   */
  public JaTooImagerPreview(final JaTooImager imager) {

    viewer = new ImageViewer();
    viewer.setPreferredSize(new Dimension(300, 100));

    //
    // prev/next buttons

    prevButton = new Button(imager.getIcon("prev-32.png"));
    prevButton.setPaintBackground(false);
    prevButton.setFocusable(false);
    prevButton.setPreferredSize(new Dimension(36, 46));
    prevButton.addActionListener(new ActionListener() {
      public void actionPerformed(final ActionEvent e) {
        imager.prevImagePreview();
      }
    });

    nextButton = new Button(imager.getIcon("next-32.png"));
    nextButton.setPaintBackground(false);
    nextButton.setFocusable(false);
    nextButton.setPreferredSize(new Dimension(36, 46));
    nextButton.addActionListener(new ActionListener() {
      public void actionPerformed(final ActionEvent e) {
        imager.nextImagePreview();
      }
    });

    //
    // zoom to real size or best fit

    zoomRealSizeBestFitButton = new ToggleButton(imager.getIcon("zoom-real-size-32.png"), imager.getIcon("zoom-best-fit-32.png.png"));
    zoomRealSizeBestFitButton.setPaintBackground(false);
    zoomRealSizeBestFitButton.setFocusable(false);
    zoomRealSizeBestFitButton.setPreferredSize(new Dimension(46, 46));
    zoomRealSizeBestFitButton.addActionListener(new ActionListener() {
      public void actionPerformed(final ActionEvent e) {
        if (zoomRealSizeBestFitButton.isSelected()) {
          viewer.setRealSize();
        } else {
          viewer.setBestFit();
        }
      }
    });

    //
    // rotate left/right buttons

    rotateLeftButton = new Button(imager.getIcon("rotate-left-32.png"));
    rotateLeftButton.setPaintBackground(false);
    rotateLeftButton.setFocusable(false);
    rotateLeftButton.setPreferredSize(new Dimension(36, 46));
    rotateLeftButton.addActionListener(new ActionListener() {
      public void actionPerformed(final ActionEvent e) {
        imager.rotateImageLeft();
      }
    });

    rotateRightButton = new Button(imager.getIcon("rotate-right-32.png"));
    rotateRightButton.setPaintBackground(false);
    rotateRightButton.setFocusable(false);
    rotateRightButton.setPreferredSize(new Dimension(36, 46));
    rotateRightButton.addActionListener(new ActionListener() {
      public void actionPerformed(final ActionEvent e) {
        imager.rotateImageRight();
      }
    });

    //
    // toolbar

    toolbar = new Panel(new MigLayout("insets 0, wrap 3"));
    toolbar.setPaintBackground(false);

    toolbar.setAlpha(0f, false);

    toolbar.add(rotateLeftButton);
    toolbar.add(zoomRealSizeBestFitButton);
    toolbar.add(rotateRightButton);

    toolbar.add(prevButton, "cell 0 1, spanx, align center");
    toolbar.add(nextButton, "cell 0 1, spanx, align center");

    toolbar.setSize(toolbar.getPreferredSize());

    //
    // loader

    loader = new JLabel(imager.getIcon("loader.gif"));
    loader.setSize(loader.getPreferredSize());
    loader.setVisible(false);

    //
    // add components and set layout

    add(loader);
    add(toolbar);
    add(viewer);

    setLayout(new LayoutManager() {

      @Override
      public void layoutContainer(final Container container) {
        synchronized (container.getTreeLock()) {

          final int containerWidth = container.getWidth();
          final int containerHeight = container.getHeight();

          viewer.setBounds(0, 0, containerWidth, containerHeight);

          toolbar.setLocation((containerWidth - toolbar.getWidth()) / 2, containerHeight - toolbar.getHeight() - (toolbar.getHeight() / 2));

          loader.setLocation((containerWidth - loader.getWidth()) / 2, (containerHeight - loader.getHeight()) / 2);
        }
      }

      @Override
      public Dimension preferredLayoutSize(final Container container) {
        synchronized (container.getTreeLock()) {
          return new Dimension(viewer.getPreferredSize());
        }
      }

      @Override
      public Dimension minimumLayoutSize(final Container container) {
        synchronized (container.getTreeLock()) {
          return new Dimension(viewer.getMinimumSize());
        }
      }

      public void addLayoutComponent(final String name, final Component comp) {}

      public void removeLayoutComponent(final Component comp) {}
    });

    //
    // watch thread for components opacity

    new Thread() {

      private final Rectangle appWindowBoundsOnScreen = new Rectangle();
      private final Rectangle toolbarBoundsOnScreen = new Rectangle();

      private int counter = 100;

      private Point mousePointerLastMoveLocation = new Point();
      private long mousePointerLastMoveTime = Long.MAX_VALUE;

      public void run() {

        Window window = null;

        while (true) {

          try {
            Thread.sleep(50);
          } catch (InterruptedException e) {}

          //
          // lazy init for window ancestor

          if (window == null) {

            window = SwingUtilities.getWindowAncestor(JaTooImagerPreview.this);

            //
            // maybe the preview is not yet in a window

            if (window == null) {
              continue;
            }
          }

          //
          // do all this stuff only if the application is showing

          if (window.isShowing()) {

            appWindowBoundsOnScreen.setLocation(window.getLocationOnScreen());
            appWindowBoundsOnScreen.setSize(window.getWidth(), window.getHeight());

            final Point mousePointerLocation = MouseInfo.getPointerInfo().getLocation();

            //
            // show components
            // if mouse pointer is over the application

            if (appWindowBoundsOnScreen.contains(mousePointerLocation)) {

              //
              // and if mouse pointer moved in last X seconds

              boolean mousePointerMoved = true;

              if (mousePointerLastMoveLocation.equals(mousePointerLocation)) {
                if (System.currentTimeMillis() - mousePointerLastMoveTime > 5000) {
                  mousePointerMoved = false;
                }
              }

              else {
                mousePointerLastMoveTime = System.currentTimeMillis();
              }

              mousePointerLastMoveLocation = mousePointerLocation;

              //
              // or if mouse pointer is over controls

              boolean mousePointerIsOverControls = false;

              if (toolbar.isShowing()) {

                toolbarBoundsOnScreen.setLocation(toolbar.getLocationOnScreen());
                toolbarBoundsOnScreen.setSize(toolbar.getWidth(), toolbar.getHeight());

                mousePointerIsOverControls = toolbarBoundsOnScreen.contains(mousePointerLocation);
              }

              //
              // but only when window has focus

              if ((mousePointerMoved || mousePointerIsOverControls) && (window.isActive() || imager.getWindow().isActive())) {

                if (counter != 0) {

                  toolbar.setAlpha(1f, true);

                  counter = 0;
                }

                continue;
              }
            }

            //
            // slowly hide the components

            counter += 5;

            if (counter >= 50 && counter < 100) {
              toolbar.setAlpha((100 - 2 * (counter - 50)) / 100f);
            }

            else if (counter >= 100) {
              toolbar.setAlpha(0f, false);
            }
          }
        }
      }
    }.start();
  }

  /**
   * Updates the image this view (content pane) will display.
   * 
   * @param image
   *          the image to be displayed, or <code>null</code> to remove the
   *          previous image
   * 
   * @see ImageViewer#setImage(BufferedImage)
   */
  public final void setImage(final BufferedImage image) {
    viewer.setImage(image);
  }

  /**
   * Shows the loader.
   */
  public final void showLoader() {
    loader.setVisible(true);
  }

  /**
   * Hides the loader.
   */
  public final void hideLoader() {
    loader.setVisible(false);
  }

}
