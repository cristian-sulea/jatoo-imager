/*
 * Copyright (C) Cristian Sulea ( http://cristian.sulea.net )
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jatoo.imager;

import jatoo.properties.FileProperties;
import jatoo.resources.ResourcesTexts;
import jatoo.ui.Button;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JToolBar;

import net.miginfocom.swing.MigLayout;

/**
 * Base class for the {@link JaTooImager} application tools.
 * 
 * @author <a href="http://cristian.sulea.net" rel="author">Cristian Sulea</a>
 * @version 1.5, September 3, 2014
 */
@SuppressWarnings("serial")
public abstract class JaTooImagerTool extends JComponent {

  private FileProperties properties;

  private ResourcesTexts texts;

  private String title;

  private JCheckBox enabledCheckBox;
  private Button restoreDefaultsButton;

  /**
   * Initialize (layout) the tool.
   * 
   * @param imager
   *          link to the {@link JaTooImager} application
   */
  public final JaTooImagerTool init(final JaTooImager imager) {

    //
    // properties are stored in a file using the full class name
    // in "tools" folder

    final File toolsFolder = new File(imager.getWorkingDirectory(), "tools");
    toolsFolder.mkdirs();

    properties = new FileProperties(new File(toolsFolder, getClass().getName() + ".properties"));
    properties.loadSilently();

    //
    // resources

    texts = new ResourcesTexts(getClass());

    //
    // title is automatically extracted from texts using package name

    title = getText("title");

    //
    // enabled/disabled checkbox

    enabledCheckBox = new JCheckBox(imager.getText("tool.enabledCheckBox.text"), properties.getPropertyAsBoolean("enabled", false));
    enabledCheckBox.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        setEnabled(enabledCheckBox.isSelected());
        imager.updatePreview();
      }
    });

    //
    // restore defaults button

    restoreDefaultsButton = new Button(imager.getIcon("restore-defaults-16.png"));
    restoreDefaultsButton.setFocusable(false);
    restoreDefaultsButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        restoreDefaults();
        imager.updatePreview();
      }
    });

    JToolBar restoreDefaultsButtonToolBar = new JToolBar();
    restoreDefaultsButtonToolBar.setFloatable(false);
    restoreDefaultsButtonToolBar.setRollover(true);
    restoreDefaultsButtonToolBar.setBorder(null);
    restoreDefaultsButtonToolBar.add(restoreDefaultsButton);

    //
    // layout

    setLayout(new MigLayout("insets 0, fillx, wrap 2", "[]push[]", "[align top][fill]"));

    add(enabledCheckBox, "wrap");
    // add(restoreDefaultsButtonToolBar);
    add(initImpl(imager, properties), "spanx, grow");

    //
    // enable/disable the tool
    // but ONLY after the #initImpl() - to have all the components created

    setEnabled(enabledCheckBox.isSelected());

    //
    // #init() completes the constructor

    return this;
  }

  @Override
  public final void setEnabled(boolean enabled) {
    super.setEnabled(enabled);
    setEnabledImpl(enabled);
  }

  public final void storeProperties() {

    properties.setProperty("enabled", enabledCheckBox.isSelected());

    storePropertiesImpl(properties);

    properties.saveSilently();
  }

  public final BufferedImage process(final BufferedImage image) {

    if (enabledCheckBox.isSelected()) {
      return processImpl(image);
    }

    else {
      return image;
    }
  }

  public final String getTitle() {
    return title;
  }

  public final String getText(final String key) {
    return texts.getText(key);
  }

  public abstract int getPriority();

  protected abstract JComponent initImpl(JaTooImager imager, FileProperties properties);

  protected abstract void setEnabledImpl(boolean enabled);

  protected abstract void storePropertiesImpl(FileProperties properties);

  protected abstract void restoreDefaults();

  protected abstract BufferedImage processImpl(BufferedImage image);

}
