/*
 * Copyright (C) Cristian Sulea ( http://cristian.sulea.net )
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jatoo.imager;

import jatoo.log4j.Log4jUtils;

import java.io.File;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * The launcher for the JaToo Imager application.
 * 
 * @author <a href="http://cristian.sulea.net" rel="author">Cristian Sulea</a>
 * @version 1.1, September 10, 2014
 */
public class JaTooImagerLauncher {

  public static void main(final String[] args) {
    launch(args, "JaToo Imager");
  }

  public static void launch(final String[] args, final String title) {

    Log4jUtils.init(JaTooImagerConfig.WORKING_DIRECTORY);

    Log logger = LogFactory.getLog(JaTooImager.class);

    try {
      UIManager.setLookAndFeel(JaTooImagerConfig.LOOK_AND_FEEL);
    } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
      logger.error("failed to set the look and feel: " + JaTooImagerConfig.LOOK_AND_FEEL, e);
    }

    JaTooImager imager = new JaTooImager(title);

    if (args != null && args.length > 0) {

      for (String arg : args) {

        //
        // in case parameter is surrounded by quotes
        // remove them

        String fileName = arg;
        fileName = fileName.trim();
        if (fileName.startsWith("\"")) {
          fileName = fileName.substring(1);
        }
        if (fileName.endsWith("\"")) {
          fileName = fileName.substring(0, fileName.length() - 1);
        }

        //
        // add parameters (files or forders)

        final File file = new File(fileName);

        if (file.exists()) {

          if (file.isFile()) {
            logger.info("file parameter: " + arg);
            imager.addFile(file);
          }

          else if (file.isDirectory()) {
            logger.info("folder parameter: " + arg);
            imager.addFolder(file);
          }

          else {
            logger.warn("not a file, not a directory, WTF... " + arg);
          }
        }

        else {
          logger.error("the provided file/directory does not exists: " + arg);
        }
      }
    }
  }
}
